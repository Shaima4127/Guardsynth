python src/test_gen_synth_data.py --modelname "mistralai/Mistral-7B-Instruct-v0.3" --gpu "3" --count_prompt 5


python src/gen_synthetic_data_llm.py --modelname "mistralai/Mistral-7B-Instruct-v0.3" --gpu "3" --count_prompt 5 --outputfile results/synthetic_data.csv



python src/gen_synthetic_data_llm.py --modelname "mistralai/Mistral-7B-Instruct-v0.3" --dataset "Aegis2" --gpu "3" --count_prompt 1 --outputfile results/Aegis2_synthetic_data.csv

python src/gen_synthetic_data_llm.py --modelname "mistralai/Mistral-7B-Instruct-v0.3" --dataset "Aegis2" --gpu "1" --count_prompt 10 --outputfile results/Aegis2_synthetic_data_10.csv


# generate method1- using mistral- 7b
python src/gen_synthetic_data_llm_5p.py --modelname "mistralai/Mistral-7B-Instruct-v0.3" --dataset "wildguardmix" --gpu "3" --count_prompt 5 --outputfile results/wildguardmix_synthetic_data_1.csv

python src/gen_synthetic_data_llm_5p.py --modelname "mistralai/Mistral-7B-Instruct-v0.3" --dataset "Aegis2" --gpu "2" --count_prompt 100 --outputfile results/Aegis2_synthetic_data_100.csv

#===================================================
# geenrate sythatic data_suning qwen 3b
#===================================================
python src/gen_synthetic_data_llm_5p.py --modelname "Qwen/Qwen2.5-7B-Instruct" --dataset "Aegis2" --gpu "1" --count_prompt 100 --outputfile results/Aegis2_synthetic_data_100_qwen.csv

python src/gen_synthetic_data_llm_5p.py --modelname "Qwen/Qwen2.5-7B-Instruct" --dataset "wildguardmix" --gpu "4" --count_prompt 100 --outputfile results/wildguardmix_synthetic_data_100_qwen.csv


## fine tuning
python src/gen_synthetic_data_finetuning_llm.py \
  --inputdata data/wildguardmix_proceed_sample.csv \
  --outputdir result/fine_tuning_data \
  --gpu 3 \
  --val_size 0.1 \
  --test_size 0.1 \
  --model_id mistralai/Mistral-7B-Instruct-v0.3 \
  --out_dir result/finetune_mistral_Guardrial \
  --use_qlora \
  --epochs 2 \
  --lr 2e-4 \
  --batch_size 4 \
  --max_len 512 \
  --merge_adapters \
  --merged_out results/finetune_mistral_Guardrial_merged



  #   
   ap.add_argument("--inputdata", required=True, help="Original dataset CSV with columns: prompt, category, label")
    ap.add_argument("--outputdir", help="Where to save prepared jsonl")
    ap.add_argument("--gpu", type=str, required=True, help="GPU id to run the code on")  
    ap.add_argument("--val_size", type=float, default=0.1)
    ap.add_argument("--test_size", type=float, default=0.1)
    ap.add_argument("--model_id", default="mistralai/Mistral-7B-Instruct-v0.3")
    ap.add_argument("--out_dir", default="result/finetune_mistral_Guardrial")
    ap.add_argument("--use_qlora", action="store_true", help="Use 4-bit QLoRA")
    ap.add_argument("--epochs", type=int, default=2)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--batch_size", type=int, default=2)
    ap.add_argument("--max_len", type=int, default=512)
    ap.add_argument("--merge_adapters", action="store_true")
    ap.add_argument("--merged_out", default="results/finetune_mistral_Guardrial_merged")

