from sklearn.model_selection import train_test_split
from typing import Optional, Dict
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.pipeline import Pipeline, make_pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, classification_report, confusion_matrix)
# pip install -U sentence-transformers  # if not installed
from sentence_transformers import SentenceTransformer
from sklearn.manifold import TSNE

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import wasserstein_distance, ks_2samp


#===============================================================
# Prepare function that we used for training & evaluation 
#===============================================================
# Trains a text classifier and returns y_pred, y_proba
def Apply_ML_Model(
    X_train,
    X_test,
    y_train,
    Model: str = 'LR',                 # 'LR' | 'SVM' | 'RF' | 'GB'
    hyperparams: Optional[Dict] = None
):
    if hyperparams is None:
        hyperparams = {}
 
    tfidf_params = {
        "max_features": 5000,
        "ngram_range": (1, 2),
        "min_df": 2,
        "stop_words": "english",
    }

    # classifier 
    if Model == 'LR':
        cls = LogisticRegression(
            C=hyperparams.get("lr_c", 10.0),
            max_iter=hyperparams.get("lr_max_iter", 100),
            #solver=hyperparams.get("lr_solver", "liblinear"),
            random_state=42
        )
        model_name = "LogisticRegression"

    elif Model == 'SVM':
        cls = SVC(
            C=hyperparams.get("svm_c", 7.0),
            kernel=hyperparams.get("svm_kernel", "rbf"),
            gamma=hyperparams.get("svm_gamma", "scale"),
            probability=True,           # enables predict_proba
            random_state=42
        )
        model_name = "SupportVectorMachine"

    elif Model == 'RF':
        cls = RandomForestClassifier(           
            n_estimators=hyperparams.get("rf_n_estimators", 100),
            max_depth=hyperparams.get("rf_max_depth", None),
            min_samples_leaf=hyperparams.get("rf_min_samples_leaf", 1),
            criterion=hyperparams.get("rf_criterion", "gini"),
            random_state=42
        )
        model_name = "RandomForestClassifier"

    elif Model == 'GB':
        cls = GradientBoostingClassifier(
            loss=hyperparams.get("loss", "log_loss"),
            criterion=hyperparams.get("criterion", "friedman_mse"),
            learning_rate=hyperparams.get("gb_learning_rate", 0.1),
            n_estimators=hyperparams.get("gb_n_estimators", 100),
            max_depth=hyperparams.get("gb_max_depth", 3),
            random_state=42
        )
        model_name = "GradientBoostingClassifier"

    else:
        raise ValueError(f"Unknown Model='{Model}'. Use one of: 'LR', 'SVM', 'RF', 'GB'.")

    # build pipeline 
    # Text path: TF-IDF + estimator
    pipeline_clf = Pipeline([("tfidf", TfidfVectorizer(**tfidf_params)), ("clf", cls),])
 

    # fit & predict 
    pipeline_clf.fit(X_train, y_train)

    y_pred = pipeline_clf.predict(X_test)
    y_proba = pipeline_clf.predict_proba(X_test)[:, 1]

    print('Machine Learning Model:', model_name)
    print('=' * 100)
    return y_pred, y_proba


def MLModel_Evaluation(
    y_predict, y_test, probs_model=None,
    ModelName="Model", ShowReport=False, ConfusionMatrix=False
):
    y_true = np.asarray(y_test).ravel()
    y_pred = np.asarray(y_predict).ravel()
    y_proba = None if probs_model is None else np.asarray(probs_model).ravel()

    # calc metrics (binary task)
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)

    # Safe AUC (works only if probs provided and both classes exist)
    try:
        auc = roc_auc_score(y_true, y_proba) if y_proba is not None else np.nan
    except ValueError:
        auc = np.nan

    # Print compact summary
    print(f"\n=== {ModelName} ===")
    print(f"Accuracy : {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall   : {rec:.4f}")
    print(f"F1-score : {f1:.4f}")
    print(f"AUC      : {auc:.4f}")

    if ShowReport:
        print(f"\nClassification Report — {ModelName}")
        print(classification_report(y_true, y_pred, zero_division=0))

    
    if ConfusionMatrix:
        conf_matrix = confusion_matrix(y_true, y_pred)
        class_labels = sorted(list(set(y_true) | set(y_pred)))
        print("=" * 100)
        print("CONFUSION MATRIX")
        sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='BuPu',
                    xticklabels=class_labels, yticklabels=class_labels)
        plt.ylabel("Actual Label")
        plt.xlabel("Predicted Label")
        plt.title(f"Confusion Matrix for {ModelName}")
        plt.show()

    return acc, prec, rec, f1, auc


# This function use to run ML model and evaluation and return the result to save them into dataframe
def run_eval(dataset, GAN_method, method, model_name, X_train, y_train, X_test, y_test,
             show_report=False, show_cm=False, hyperparams= None):
    
    # Apply_ML_Model which will train the selected ML model
    y_pred, y_proba = Apply_ML_Model(X_train=X_train, X_test=X_test, y_train=y_train, Model=model_name, hyperparams= hyperparams)
    
    # MLModel_Evaluation returns: acc, prec, rec, f1, auc  (in that order)
    acc, prec, rec, f1, auc = MLModel_Evaluation(
        y_predict=y_pred, y_test=y_test, probs_model=y_proba,
        ModelName=f"{method} - {model_name}",ShowReport=show_report, ConfusionMatrix=show_cm
    )
    return {"dataset": dataset, "GAN_method":GAN_method, "ml_model": model_name, "method": method, "acc": acc, "f1_score": f1, "auc": auc}


def evaluate_utility(
    dataset,
    GAN_method, 
    original_df,
    synth_df,
    models = ("LR", "SVM", "RF", "GB"),
    test_size= 0.2,
    show_report = False,
    show_cm= False,
    save_path = None,
   hyperparams= None
):
    """
    Runs utility evaluation using two approaches:
      - TSTR: Train on synthetic, test on real(test)
      - TRTR: Train on real(train), test on real(test)
    Returns:
      results_df with columns: ['dataset','ml_model','method','acc','f1_score','auc']
    """
    # 1) Split REAL once for fairness (baseline uses this split)
    train_real, test_real = train_test_split(
        original_df, test_size=test_size, random_state=42,
        stratify=original_df['label']
    )

    rows = []

    # 2) TSTR: train on synthetic → test on real(test)
    for m in models:
        print("evaluate using ML:", m)
        rows.append(run_eval( dataset= dataset, GAN_method = GAN_method,
            method="TSTR", model_name=m,
            X_train=synth_df["prompt"], y_train=synth_df["label"],
            X_test=test_real["prompt"],  y_test=test_real["label"],
            hyperparams = hyperparams
        ))

    # 3) TRTR: train on real(train) → test on real(test)
    for m in models:
        rows.append(run_eval( dataset= dataset, GAN_method = GAN_method,
            method="TRTR", model_name=m,
            X_train=train_real["prompt"], y_train=train_real["label"],
            X_test=test_real["prompt"],   y_test=test_real["label"],
            hyperparams = hyperparams
        ))

    results_df = pd.DataFrame(rows).sort_values(["dataset", "method", "ml_model"]).reset_index(drop=True)

    if save_path:
        results_df.to_csv(save_path, index=False)

    return results_df



def plot_ml_comparison(
    df,
    method= "TRTR",
    metrics = ("acc", "f1_score", "auc"),
    title= None,
    palette= "pastel"
):
    """
    Plot a grouped bar chart for a chosen method ('TRTR' or 'TSTR').
    Expects df columns: ['dataset','ml_model','method','acc','f1_score','auc'].
    """
    data = df[df["method"] == method].copy()
    if data.empty:
        raise ValueError(f"No rows found for method '{method}'.")

    # Consistent model order if present
    preferred = ["LR", "RF", "SVM", "GB"]
    present = [m for m in preferred if m in set(data["ml_model"])]
    if len(present) == data["ml_model"].nunique():
        data["ml_model"] = pd.Categorical(data["ml_model"], categories=present, ordered=True)
        data = data.sort_values("ml_model")

    # Rename metrics for pretty legend labels
    rename_map = {"acc":"Accuracy", "f1_score":"F1_Score", "auc":"AUC"}
    labels = [rename_map.get(m, m) for m in metrics]

    # Build plotting frame
    plot_df = data[["ml_model", *metrics]].rename(columns=dict(zip(metrics, labels)))
    plot_df = plot_df.set_index("ml_model")

    # Colors
    colors = sns.color_palette(palette, n_colors=len(labels))

    # Plot
    ax = plot_df.plot(kind="bar", color=colors, width=0.50, rot=0, figsize=(6,4),
                      title=title or f"ML Model Comparison — {method}")

    ax.set_xlabel("Machine Learning Models", fontsize=10)
    ax.set_ylabel("Score", fontsize=10)
    ax.set_ylim(0, 1)
    ax.tick_params(axis="both", labelsize=11)
    plt.grid(axis="y", linestyle="--", alpha=0.6)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.15), ncol=len(labels), fancybox=True)
    plt.tight_layout()
    plt.show()




def plot_KDE(original_df, synth_df, feature, title):
    plt.figure(figsize=(6, 4))
    
    # KDE for original
    sns.kdeplot(original_df[feature], color="blue", label="Original", fill=True, alpha=0.3, linewidth=2)
    
    # KDE for synthetic
    sns.kdeplot(synth_df[feature], color="orange", label="Synthetic", fill=True, alpha=0.3, linewidth=2)
    
    plt.title(f"KDE for {title}")
    plt.xlabel(feature)
    plt.ylabel("Density")
    plt.legend()
    plt.show()



def compare_summary_stats_table(
    original_df: pd.DataFrame,
    synth_df: pd.DataFrame,
    features,
    stats=("count","mean","std","median","min","max","q1","q3"),
    round_decimals=3
) -> pd.DataFrame:
    """
    Returns a table with two columns (Original, Synthetic) and rows as statistics.
    If multiple features are provided, the rows are a MultiIndex: (feature, statistic).
    """
    def compute_stats(s: pd.Series) -> dict:
        q1 = s.quantile(0.25)
        q3 = s.quantile(0.75)
        return {
            "count":  s.count(),
            "mean":   s.mean(),
            "std":    s.std(),
            "median": s.median(),
            "min":    s.min(),
            "max":    s.max(),
            "q1":     q1,
            "q3":     q3,
            "iqr":    q3 - q1,
        }

    rows = []
    data = []
    for feat in features:
        o_stats = compute_stats(original_df[feat].dropna())
        s_stats = compute_stats(synth_df[feat].dropna())
        for stat in stats:
            rows.append((feat, stat))
            data.append([o_stats.get(stat, np.nan), s_stats.get(stat, np.nan)])

    out = pd.DataFrame(data, index=pd.MultiIndex.from_tuples(rows, names=["feature","statistic"]),
                       columns=["Original", "Synthetic"])
    if round_decimals is not None:
        out = out.round(round_decimals)
    return out





def plot_TSNE(dataset, original_df, synth_df):
    # 1) Prepare combined dataframe as above
    orig = original_df.copy(); synth = synth_df.copy()
    orig["source"] = "Original"; synth["source"] = "Synthetic"
    df = pd.concat([orig, synth], ignore_index=True)

    # 2) Encode to dense embeddings (pick a small, fast model)
    model = SentenceTransformer("all-MiniLM-L6-v2")  # 384-dim
    emb = model.encode(df["prompt"].tolist(), show_progress_bar=True, normalize_embeddings=True)

    # 3) t-SNE
    tsne = TSNE(n_components=2, perplexity=30, init="pca", random_state=42)
    emb_2d = tsne.fit_transform(emb)

    # 4) Plot
    plot_df = pd.DataFrame({
        "x": emb_2d[:,0], "y": emb_2d[:,1],
        "source": df["source"],
        "label": df["label"].map({0:"safe",1:"unsafe"}),
        "category": df["category"]
    })
    sns.scatterplot(data=plot_df, x="x", y="y", hue="source", style="label", alpha=0.75, s=35)
    plt.title(f"t-SNE of prompts-embeddings in {dataset}")
    plt.tight_layout(); 
    plt.show()



def prep_numeric(series):
    """Coerce to numeric and drop NaNs."""
    return pd.to_numeric(series, errors="coerce").dropna().to_numpy()

# This function measures fidelity by comparing the distribution of prompt lengths in real vs synthetic datasets:
# Wasserstein Distance → how different are the two distributions in shape/location.
# KS Test → statistical hypothesis test if they could come from the same distribution.
def compare_prompt_lengths(dataset, GAN_method, original_df, synth_df, col="prompt_tokens"):
    """Return Wasserstein distance and KS test between real vs synthetic lengths."""
    x = prep_numeric(original_df[col])
    y = prep_numeric(synth_df[col])

    wass = float(wasserstein_distance(x, y))
    ks_res = ks_2samp(x, y, alternative="two-sided", mode="auto")

    return {
        "dataset":dataset,
        "GAN_method": GAN_method,
        "feature": col,
        "n_real": len(x),
        "n_synth": len(y),
        "wasserstein_distance": wass,
        "ks_stat": float(ks_res.statistic),
        "ks_pvalue": float(ks_res.pvalue),
    }


def plot_length_distributions(original_df, synth_df, col="prompt_tokens", bins="auto", title = ""):
    """Show histogram + ECDF side by side for real vs synthetic lengths."""
    x = prep_numeric(original_df[col])
    y = prep_numeric(synth_df[col])

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    # 1) Overlaid histograms (density)
    axes[0].hist(x, bins=bins, density=True, alpha=0.5, label="Real")
    axes[0].hist(y, bins=bins, density=True, alpha=0.5, label="Synthetic")
    axes[0].set_xlabel(col)
    axes[0].set_ylabel("Density")
    axes[0].set_title(f"Histogram of {col} for {title}")
    axes[0].legend()

    # 2) ECDFs
    def ecdf(arr):
        arr = np.sort(arr)
        n = arr.size
        return arr, np.arange(1, n + 1) / n

    xr, Fr = ecdf(x)
    ys, Fs = ecdf(y)

    axes[1].step(xr, Fr, where="post", label="Real")
    axes[1].step(ys, Fs, where="post", label="Synthetic")
    axes[1].set_xlabel(col)
    axes[1].set_ylabel("ECDF")
    axes[1].set_title(f"ECDF of {col} for {title}")
    axes[1].legend()

    plt.tight_layout()
    plt.show()


def plot_TSNE_small(dataset, original_df, synth_df, title=None,
                    perplexity=30, figsize=(3.2, 4.4),
                    point_size=10, alpha_syn=0.70, alpha_org=0.90):
    # Combine
    orig = original_df.copy(); synth = synth_df.copy()
    orig["Source"] = "Original"; synth["Source"] = "Synthetic"
    df = pd.concat([orig, synth], ignore_index=True)

    # Embeddings
    model = SentenceTransformer("all-MiniLM-L6-v2")
    emb = model.encode(df["prompt"].tolist(), batch_size=64,
                       show_progress_bar=True, normalize_embeddings=True)

    # t-SNE
    max_perp = max(5, min(perplexity, (len(df) - 1) // 3))
    tsne = TSNE(n_components=2, perplexity=max_perp, init="pca", random_state=42)
    e2d = tsne.fit_transform(emb)

    plot_df = pd.DataFrame({"x": e2d[:,0], "y": e2d[:,1], "Source": df["Source"].values})
    syn = plot_df["Source"].eq("Synthetic").values
    org = ~syn

    # Figure (compact)
    fig, ax = plt.subplots(figsize=figsize)
    ax.grid(True, which="both", alpha=0.35, linewidth=0.6)

    # Draw synthetic first, original on top
    ax.scatter(plot_df.loc[syn,"x"], plot_df.loc[syn,"y"],
               s=point_size, c="#E06666", alpha=alpha_syn,
               edgecolors="white", linewidths=0.25, label="Synthetic", zorder=1)
    ax.scatter(plot_df.loc[org,"x"], plot_df.loc[org,"y"],
               s=point_size, c="#6FA8DC", alpha=alpha_org,
               edgecolors="white", linewidths=0.25, label="Original", zorder=2)

    # Compact styling
    ax.set_xlabel(""); ax.set_ylabel("")
    ax.tick_params(labelsize=8, pad=1)
    step = 25
    xmin, xmax = ax.get_xlim(); ymin, ymax = ax.get_ylim()
    ax.set_xticks(np.arange(np.floor(xmin/step)*step, np.ceil(xmax/step)*step + 1, step))
    ax.set_yticks(np.arange(np.floor(ymin/step)*step, np.ceil(ymax/step)*step + 1, step))

    ax.set_title(title or f"{dataset}", fontsize=10,  pad=6)
    leg = ax.legend(loc="upper right", frameon=True, fontsize=8,
                    borderpad=0.2, labelspacing=0.2, handletextpad=0.3)
    for h in leg.legend_handles: h.set_sizes([30])

    plt.tight_layout(pad=0.3)
    plt.show()


